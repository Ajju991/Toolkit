function showTool(id) {
  document.querySelectorAll('.tool-container').forEach(el => el.style.display = 'none');
  document.getElementById(id).style.display = 'block';
}
function countWords() {
  const text = document.getElementById('wordInput').value.trim();
  const words = text.split(/\s+/).filter(Boolean);
  document.getElementById('wordResult').innerText = `Word count: ${words.length}`;
}
function countChars() {
  const text = document.getElementById('charInput').value;
  document.getElementById('charResult').innerText = `Character count: ${text.length}`;
}
